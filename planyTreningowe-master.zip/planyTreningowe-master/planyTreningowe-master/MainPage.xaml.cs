﻿namespace planyTreningowe
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();

            // Usuwa domyślne podkreślenie pól tekstowych na Androidzie.
            Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping("NoUnderline", (handler, view) =>
            {
            #if ANDROID
                handler.PlatformView.Background = null;
            #endif
            });
        }

        private async void TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
        {
            // RegisterView jest zarejestrowany jako trasa w AppShell.
            await Shell.Current.GoToAsync(nameof(RegisterView));
        }

        private void loginButton_Clicked(object sender, EventArgs e)
        {
            Console.WriteLine("Logowanie nie jest jeszcze podłączone.");
        }
    }

}
